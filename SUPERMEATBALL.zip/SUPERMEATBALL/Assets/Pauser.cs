﻿using UnityEngine;
using System.Collections;

public class Pauser : MonoBehaviour {

	public bool isPaused = false;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
		if (Input.GetButtonDown ("Start") || Input.GetKeyDown(KeyCode.Escape)) {
			Movement.canMove = true;
		//	isPaused = !isPaused;
			Application.LoadLevel("Menu");
			//GameObject.Find("GameMusic").audio.Stop();

		//	Destroy(GameObject.Find("GameMusic"));
				}

	/*	if (isPaused == true) {


			Time.timeScale = 0;
		

				}

		if (isPaused == false) {
			Time.timeScale = 1;

				}
*/
	}




}
