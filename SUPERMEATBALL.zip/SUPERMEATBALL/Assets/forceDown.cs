﻿using UnityEngine;
using System.Collections;

public class forceDown : MonoBehaviour {

	public static bool movement = false;
	public GameObject player;


	

	void OnTriggerEnter() {


		movement = true;

		}

	void OnTriggerExit() {
		movement = false;
		}

}
