﻿using UnityEngine;
using System.Collections;

public class GOGui : MonoBehaviour
{

	public Camera sceneCamera;
	public Camera mainCam;
	bool canStart = false;
	public GameObject goObject;
	bool hasStarted = false;


		void Start ()
		{
		mainCam.enabled = false;
		sceneCamera.enabled = true;
		Movement.canMove = false;		
		goObject.SetActive (false);
				
		}


		// Update is called once per frame
		void Update ()
		{

		if (Input.GetButtonDown ("Xbutton") && hasStarted == false || Input.GetKeyDown(KeyCode.X) && hasStarted == false) {
						StartCoroutine (beginGo ());
						hasStarted = true;
						Destroy(GameObject.Find("PressX"));
						Destroy(GameObject.Find ("thisFloor"));
			goObject.audio.Play();
				}
				
	
		}

		IEnumerator beginGo ()
		{

				goObject.SetActive (true);
				//Component script = GameObject.Find ("meatballm").GetComponent<Movement>;
				sceneCamera.enabled = false;
				mainCam.enabled = true;
				
				yield return new WaitForSeconds (1.0f);

				Movement.canMove = true;
				
				goObject.SetActive (false);
				
		}

		void beginStart ()
		{
				mainCam.enabled = false;
				sceneCamera.enabled = true;
				Movement.canMove = false;
				if (canStart == true) {
						StartCoroutine (beginGo ());

				}
		}




}

