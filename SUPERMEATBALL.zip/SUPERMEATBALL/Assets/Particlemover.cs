﻿using UnityEngine;
using System.Collections;

public class Particlemover : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 PlayerPOS = GameObject.Find("meatballm").transform.transform.position;
		GameObject.Find("Particle System").transform.position = new Vector3(PlayerPOS.x, PlayerPOS.y-0.2f, PlayerPOS.z);
	}
}
