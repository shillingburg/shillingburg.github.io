﻿using UnityEngine;
using System.Collections;

public class SpatulaBehavior : MonoBehaviour {

	public GameObject meatball;
	public GameObject pointofnoreturn;
	public AnimationState ok;

	// Use this for initialization
	void Start () {
	

	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetMouseButtonDown (0)) {
			animation.Play("Flip");
		}

	
	}

	void OnCollisionEnter (Collision col)
	{
	/*	if(meatball)
		{
			meatball.transform.localPosition = pointofnoreturn.transform.localPosition;
			animation.Play("Flip");

		}
*/


	
	}
}
