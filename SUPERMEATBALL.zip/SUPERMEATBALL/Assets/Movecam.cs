﻿using UnityEngine;
using System.Collections;

public class Movecam : MonoBehaviour {

	public GameObject ballGameObject;
	public GameObject cameraBox;


	public float riseHeight = 10f;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		int DistanceAway = 6;
		Vector3 PlayerPOS = GameObject.Find("meatballm").transform.transform.position;
		GameObject.Find("Camera").transform.position = new Vector3(PlayerPOS.x, PlayerPOS.y+riseHeight, PlayerPOS.z - DistanceAway);
	

		/*

		transform.LookAt(ballGameObject.transform.localPosition);

		float rotateAmount = Input.GetAxis ("RightH");

	

		if (Input.GetAxis ("RightH")!= 0) {
			transform.RotateAround(ballGameObject.transform.localPosition, Vector3.up, rotateAmount);
				}

		*/


		//transform.position = ballGameObject.transform.position;
		//transform.LookAt(transform.position + ballGameObject.rigidbody.velocity);

	}
}
