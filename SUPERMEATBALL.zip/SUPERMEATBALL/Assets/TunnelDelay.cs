﻿using UnityEngine;
using System.Collections;

public class TunnelDelay : MonoBehaviour {

	public float timeToWait;


	// Use this for initialization
	void Start () {

		StartCoroutine (TunnelTime ());
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	IEnumerator TunnelTime () {
		yield return new WaitForSeconds (timeToWait); 
		animation.Play();
	}

}
