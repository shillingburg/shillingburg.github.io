﻿using UnityEngine;
using System.Collections;

public class CameraColliderFloor3 : MonoBehaviour {

	public Camera topCam;
	public Camera mainCam;
	public GameObject meatball;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}


	void OnTriggerEnter() {
		if (GameObject.Find("meatballm")) {
						topCam.enabled = true;
				}

	}

}
