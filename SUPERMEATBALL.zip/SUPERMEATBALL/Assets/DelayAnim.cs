﻿using UnityEngine;
using System.Collections;

public class DelayAnim : MonoBehaviour {

	// Use this for initialization
	void Start () {
		animation.Stop ();
		StartCoroutine(DelayAnimation(1.1f));
	}
	
	// Update is called once per frame
	void Update () {
	
	


	}


	IEnumerator DelayAnimation (float secondsToWait)
	{
		
		yield return new WaitForSeconds (secondsToWait);
		animation.Play();

		
	}
}
