﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour
{
	
		public float speed;
		public GameObject floor;
		public Camera mainCam;
		public GameObject boundsTrigger;
		public GameObject reset;
		public GameObject goalFence;
		public Camera endCam;
		public float zPos;
		public AudioClip pchoop;
		public Camera topCam;
		public int levelCount;
		public static bool canMove = true;
		GameObject accepter;
		
	
	
		// Use this for initialization
		void Start ()
		{
		accepter = GameObject.Find ("Accepter");
		}
	
		// Update is called once per frame
		void FixedUpdate ()
		{
		
				float moveHorizontal = Input.GetAxis ("Horizontal");
				float moveVertical = Input.GetAxis ("Vertical");

				//Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);
				Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);
				//Transform cameraAngle = mainCam.transform;



				if (movement == Vector3.zero) {
				
						if (forceDown.movement) {

						} else
								return;
				}

				if (canMove == true) {
						rigidbody.AddForce (movement * speed * Time.deltaTime);
				}

	

				//rigidbody.AddForce (mainCam.transform.forward *speed *Time.deltaTime);
		
		
		}
	
	
/*	void OnTriggerEnter(Collider other) {
		gameObject.SetActive (false);
	}

*/


		void OnTriggerEnter (Collider bounds)
		{
				if (bounds.gameObject.tag == "outofbounds") {
						transform.localPosition = reset.transform.localPosition;
						rigidbody.velocity = Vector3.zero;
						audio.PlayOneShot (pchoop);
				}
	
				if (bounds.gameObject.name == "CameraCollider") {
						mainCam.enabled = false;
						topCam.enabled = true;
				}

				if (bounds.gameObject.name == "Cube") {

			gameObject.SetActive(false);

		
		}

		}

		IEnumerator TransitionLevel (string levelToLoad)
		{
				Debug.Log ("STARTED!");
				yield return new WaitForSeconds (3.0f);
				Debug.Log ("ENDED!");
				Application.LoadLevel (levelToLoad);
		}

		void OnTriggerExit (Collider bounds)
		{
				if (bounds.gameObject.tag == "goalfence") {
						mainCam.enabled = false;
						endCam.enabled = true;
						canMove = false;
						levelCount++;
						StartCoroutine (TransitionLevel ("FLOOR" + levelCount));
						accepter.audio.Play();
						GameObject.Find("BoundsTrigger").SetActive(false);
						
				}

				if (bounds.gameObject.name == "CameraCollider") {
						topCam.enabled = false;
						mainCam.enabled = true;
				}
		}

}

	