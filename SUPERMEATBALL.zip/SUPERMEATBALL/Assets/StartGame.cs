﻿using UnityEngine;
using System.Collections;

public class StartGame : MonoBehaviour {

	public GameObject thisStupid;

	public bool final = false;

	// Use this for initialization
	void Start () {
	
		Destroy (GameObject.Find ("GameMusic"));
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetButtonDown("Xbutton") && final == false || Input.GetKeyDown("x") && final == false) {
			StartCoroutine(LoadTimer());

				}

		if (Input.GetButtonDown ("Xbutton") && final == true || Input.GetKeyDown("x") && final == true) {
			Application.LoadLevel("Menu");
				}

	
	}


	IEnumerator LoadTimer() {
		audio.Play();
		yield return new WaitForSeconds(1);
		Application.LoadLevel("FLOOR1");

	}
}
