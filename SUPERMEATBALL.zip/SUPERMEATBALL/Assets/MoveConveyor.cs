﻿using UnityEngine;
using System.Collections;

public class MoveConveyor : MonoBehaviour {

	public float scrollSpeed;
	public GameObject meatballm;
	public bool left;
	private Vector3 dir;
	public int conveyorspeed = 10;
	private Vector3 meatForce;
	
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		float offset = Time.time * scrollSpeed % 1;

		this.renderer.material.SetTextureOffset("_MainTex", new Vector2(-offset, 0));

		if(left) {dir = Vector3.left;} else {dir = Vector3.right;}

		Vector3 currentForce = meatballm.rigidbody.velocity;
		meatForce = currentForce;


			
	}

	void OnCollisionStay() {
		if (meatballm) {
		//	meatballm.rigidbody.AddRelativeTorque(Vector3.up*12000*Time.deltaTime);


		meatballm.rigidbody.AddForce(dir*conveyorspeed - meatForce);

	
			//meatballm.rigidbody.velocity = Vector3.left*200*Time.deltaTime;

				}

	}

}
